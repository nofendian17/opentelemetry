package logging

import (
	"context"
	"log/slog"
	"os"
	"strings"

	"go.opentelemetry.io/otel/trace"
)

// Logger defines a minimal structured logger interface used by the app.
type Logger interface {
	InfoContext(ctx context.Context, msg string, kvs ...any)
	Info(msg string, kvs ...any)
	ErrorContext(ctx context.Context, msg string, kvs ...any)
	Error(msg string, kvs ...any)
	Debug(msg string, kvs ...any)
	With(kvs ...any) Logger
}

// slogAdapter adapts the standard library slog to the Logger interface.
type slogAdapter struct {
	l *slog.Logger
}

// NewLogger creates a new slog-backed Logger with configurable level and base key-values.
func NewLogger(level string, kvs ...any) Logger {
	handler := slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
		Level: parseLevel(level),
	})
	logger := slog.New(handler).With(kvs...)
	return &slogAdapter{l: logger}
}

func traceFieldsFromContext(ctx context.Context) []any {
	sc := trace.SpanFromContext(ctx).SpanContext()
	if !sc.IsValid() {
		return nil
	}
	return []any{"trace_id", sc.TraceID().String(), "span_id", sc.SpanID().String()}
}

func (s *slogAdapter) InfoContext(ctx context.Context, msg string, kvs ...any) {
	kvs = append(traceFieldsFromContext(ctx), kvs...)
	s.l.Info(msg, kvs...)
}

func (s *slogAdapter) Info(msg string, kvs ...any) {
	s.l.Info(msg, kvs...)
}

func (s *slogAdapter) ErrorContext(ctx context.Context, msg string, kvs ...any) {
	kvs = append(traceFieldsFromContext(ctx), kvs...)
	s.l.Error(msg, kvs...)
}

func (s *slogAdapter) Error(msg string, kvs ...any) {
	s.l.Error(msg, kvs...)
}

func (s *slogAdapter) Debug(msg string, kvs ...any) {
	s.l.Debug(msg, kvs...)
}

func (s *slogAdapter) With(kvs ...any) Logger {
	return &slogAdapter{l: s.l.With(kvs...)}
}

// parseLevel converts string to slog.Level
func parseLevel(l string) slog.Level {
	switch strings.ToLower(l) {
	case "debug":
		return slog.LevelDebug
	case "warn", "warning":
		return slog.LevelWarn
	case "error":
		return slog.LevelError
	case "info":
		fallthrough
	default:
		return slog.LevelInfo
	}
}
