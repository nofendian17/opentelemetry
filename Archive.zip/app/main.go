package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/metric"

	"app/telemetry"
)

// Application represents our main application
type Application struct {
	*telemetry.Application // Embedded telemetry application
}

// statusRecorder wraps http.ResponseWriter to capture status code
type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *statusRecorder) WriteHeader(code int) {
	r.status = code
	r.ResponseWriter.WriteHeader(code)
}

// instrument wraps handlers to record metrics (requests, duration, inflight, errors)
func (a *Application) instrument(route string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		ctx := r.Context()
		a.InflightRequests.Add(ctx, 1)
		rec := &statusRecorder{ResponseWriter: w, status: 200}
		defer func() {
			a.InflightRequests.Add(ctx, -1)
			duration := time.Since(start).Seconds()

			attrs := attribute.NewSet(
				attribute.String("http.method", r.Method),
				attribute.String("http.route", route),
				attribute.Int("http.status_code", rec.status),
			)

			a.RequestCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
			a.RequestDuration.Record(ctx, duration, metric.WithAttributeSet(attrs))
			if rec.status >= 500 {
				a.ErrorCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
			}
		}()

		next.ServeHTTP(rec, r)
	})
}

// handleRequest handles HTTP requests with telemetry
func (a *Application) handleRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	a.Logger.InfoContext(ctx, "Processing HTTP request",
		"method", r.Method,
		"url", r.URL.String(),
	)

	// Simulate work
	time.Sleep(100 * time.Millisecond)

	// Simulate a child span operation
	a.processData(ctx)

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Hello, OpenTelemetry!\n")

	a.Logger.InfoContext(ctx, "Successfully processed request",
		"method", r.Method,
		"url", r.URL.String(),
		"status", 200,
	)
}

// processData simulates processing data with a child span
func (a *Application) processData(ctx context.Context) {
	_, span := a.Tracer.Start(ctx, "processData")
	defer span.End()

	span.SetAttributes(
		attribute.String("process.type", "data-processing"),
		attribute.Int("data.size", 100),
	)

	a.Logger.InfoContext(ctx, "Processing data",
		"type", "data-processing",
		"size", 100,
	)

	time.Sleep(50 * time.Millisecond)

	a.Logger.InfoContext(ctx, "Data processing completed")
}

// healthCheck handles health check requests
func (a *Application) healthCheck(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	a.Logger.InfoContext(ctx, "Health check requested")
	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "OK\n")
	a.Logger.InfoContext(ctx, "Health check completed successfully")
}

func main() {
	// Initialize application with telemetry
	appTelemetry, tp, mp, err := telemetry.InitTelemetry()
	if err != nil {
		log.Fatalf("Failed to initialize application telemetry: %v", err)
	}

	app := &Application{
		Application: appTelemetry,
	}

	// HTTP mux with instrumentation
	mux := http.NewServeMux()

	helloHandler := http.HandlerFunc(app.handleRequest)
	healthHandler := http.HandlerFunc(app.healthCheck)

	// Wrap with otelhttp (for automatic span) then internal instrumentation (metrics)
	mux.Handle("/hello",
		app.instrument("hello",
			otelhttp.NewHandler(helloHandler, "hello"),
		),
	)
	mux.Handle("/health",
		app.instrument("health",
			otelhttp.NewHandler(healthHandler, "health"),
		),
	)

	port := getEnv("APP_PORT", "8080")

	srv := &http.Server{
		Addr:    ":" + port,
		Handler: mux,
	}

	app.Logger.Info("Starting server", "port", port)

	// Graceful shutdown handling
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			app.Logger.Error("HTTP server error", "error", err)
		}
	}()

	<-ctx.Done()
	app.Logger.Info("Shutdown signal received, commencing graceful shutdown")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	if err := srv.Shutdown(shutdownCtx); err != nil {
		app.Logger.Error("HTTP server graceful shutdown failed", "error", err)
	} else {
		app.Logger.Info("HTTP server stopped cleanly")
	}

	// Flush telemetry providers with timeout
	flushCtx, cancelFlush := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancelFlush()

	if err := tp.Shutdown(flushCtx); err != nil {
		app.Logger.Error("Error shutting down tracer provider", "error", err)
	}
	if err := mp.Shutdown(flushCtx); err != nil {
		app.Logger.Error("Error shutting down meter provider", "error", err)
	}

	app.Logger.Info("Shutdown complete")
}

func getEnv(k, def string) string {
	v := os.Getenv(k)
	if v == "" {
		return def
	}
	return v
}
