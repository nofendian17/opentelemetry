package telemetry

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"time"

	"app/logging"

	"github.com/google/uuid"

	"go.opentelemetry.io/contrib/instrumentation/runtime"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetrichttp"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/propagation"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	sdkresource "go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"
)

// Environment variable keys
const (
	envEndpoint        = "OTEL_EXPORTER_OTLP_ENDPOINT"
	envServiceName     = "OTEL_SERVICE_NAME"
	envServiceVersion  = "OTEL_SERVICE_VERSION"
	envDeploymentEnv   = "OTEL_ENV"
	envSamplerRatio    = "OTEL_TRACES_SAMPLER_RATIO"
	envLogLevel        = "LOG_LEVEL"
	defaultEndpoint    = "otel-collector:4318"
	defaultServiceName = "opentelemetry-app"
	defaultVersion     = "1.0.0"
	defaultEnv         = "dev"
)

// Application represents our main application with telemetry components
type Application struct {
	Tracer trace.Tracer
	Meter  metric.Meter
	Logger logging.Logger

	// Metrics
	RequestCount     metric.Int64Counter
	ErrorCount       metric.Int64Counter
	InflightRequests metric.Int64UpDownCounter
	RequestDuration  metric.Float64Histogram
}

// InitTelemetry initializes a new application with telemetry
func InitTelemetry() (*Application, *sdktrace.TracerProvider, *sdkmetric.MeterProvider, error) {
	// Load configuration from environment
	cfg := loadConfigFromEnv()

	// Initialize tracer & meter providers
	tp, err := initTracer(cfg)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to initialize tracer: %w", err)
	}

	mp, err := initMeter(cfg)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to initialize meter: %w", err)
	}

	// Create a named tracer and meter
	tracer := tp.Tracer(cfg.ServiceName)
	meter := mp.Meter(cfg.ServiceName)

	// Create a logger enriched with resource attributes
	logger := logging.NewLogger(cfg.LogLevel,
		"service.name", cfg.ServiceName,
		"service.version", cfg.ServiceVersion,
		"deployment.environment", cfg.DeploymentEnv,
	)

	// Create metrics
	requestCount, err := meter.Int64Counter(
		"http.server.requests.total",
		metric.WithDescription("Total number of HTTP server requests"),
	)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to create request counter: %w", err)
	}

	errorCount, err := meter.Int64Counter(
		"http.server.errors.total",
		metric.WithDescription("Total number of HTTP server error responses (5xx)"),
	)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to create error counter: %w", err)
	}

	inflight, err := meter.Int64UpDownCounter(
		"http.server.inflight_requests",
		metric.WithDescription("Current number of inflight HTTP server requests"),
	)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to create inflight counter: %w", err)
	}

	requestDuration, err := meter.Float64Histogram(
		"http.server.request.duration.seconds",
		metric.WithDescription("HTTP server request duration in seconds"),
		metric.WithUnit("s"),
	)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to create request duration histogram: %w", err)
	}

	// Start runtime instrumentation (GC, memstats, goroutines, etc.)
	if err := runtime.Start(
		runtime.WithMinimumReadMemStatsInterval(10*time.Second),
		runtime.WithMeterProvider(mp),
	); err != nil {
		logger.Error("Failed to start runtime instrumentation", "error", err)
	}

	logger.Info("Telemetry initialized",
		"endpoint", cfg.Endpoint,
		"sampler_ratio", cfg.SamplerRatio,
	)

	return &Application{
		Tracer:           tracer,
		Meter:            meter,
		Logger:           logger,
		RequestCount:     requestCount,
		ErrorCount:       errorCount,
		InflightRequests: inflight,
		RequestDuration:  requestDuration,
	}, tp, mp, nil
}

type config struct {
	Endpoint       string
	ServiceName    string
	ServiceVersion string
	DeploymentEnv  string
	SamplerRatio   float64
	LogLevel       string
	InstanceID     string
}

// loadConfigFromEnv reads environment variables with defaults.
func loadConfigFromEnv() config {
	endpoint := getEnv(envEndpoint, defaultEndpoint)
	serviceName := getEnv(envServiceName, defaultServiceName)
	serviceVersion := getEnv(envServiceVersion, defaultVersion)
	deploymentEnv := getEnv(envDeploymentEnv, defaultEnv)
	logLevel := getEnv(envLogLevel, "info")
	instanceID := uuid.NewString()

	ratioStr := getEnv(envSamplerRatio, "1.0")
	ratio, err := strconv.ParseFloat(ratioStr, 64)
	if err != nil || ratio < 0 || ratio > 1 {
		log.Printf("Invalid %s=%s, falling back to 1.0", envSamplerRatio, ratioStr)
		ratio = 1.0
	}

	return config{
		Endpoint:       endpoint,
		ServiceName:    serviceName,
		ServiceVersion: serviceVersion,
		DeploymentEnv:  deploymentEnv,
		SamplerRatio:   ratio,
		LogLevel:       logLevel,
		InstanceID:     instanceID,
	}
}

func getEnv(k, def string) string {
	v := os.Getenv(k)
	if v == "" {
		return def
	}
	return v
}

// initTracer creates a new trace provider and exporter
func initTracer(cfg config) (*sdktrace.TracerProvider, error) {
	exporter, err := otlptracehttp.New(context.Background(),
		otlptracehttp.WithEndpoint(cfg.Endpoint),
		otlptracehttp.WithInsecure(),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create trace exporter: %w", err)
	}

	// Build resource
	res, err := buildResource(cfg)
	if err != nil {
		return nil, fmt.Errorf("failed to build resource: %w", err)
	}

	tp := sdktrace.NewTracerProvider(
		sdktrace.WithBatcher(exporter),
		sdktrace.WithSampler(
			sdktrace.ParentBased(sdktrace.TraceIDRatioBased(cfg.SamplerRatio)),
		),
		sdktrace.WithResource(res),
	)
	otel.SetTracerProvider(tp)
	otel.SetTextMapPropagator(
		propagation.NewCompositeTextMapPropagator(
			propagation.TraceContext{},
			propagation.Baggage{},
		),
	)
	return tp, nil
}

// initMeter creates a new meter provider and exporter
func initMeter(cfg config) (*sdkmetric.MeterProvider, error) {
	exporter, err := otlpmetrichttp.New(context.Background(),
		otlpmetrichttp.WithEndpoint(cfg.Endpoint),
		otlpmetrichttp.WithInsecure(),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create metric exporter: %w", err)
	}

	// Use periodic reader
	reader := sdkmetric.NewPeriodicReader(exporter, sdkmetric.WithInterval(15*time.Second))

	// Resource (reuse)
	res, err := buildResource(cfg)
	if err != nil {
		return nil, fmt.Errorf("failed to build resource for metrics: %w", err)
	}

	mp := sdkmetric.NewMeterProvider(
		sdkmetric.WithReader(reader),
		sdkmetric.WithResource(res),
	)
	otel.SetMeterProvider(mp)
	return mp, nil
}

func buildResource(cfg config) (*sdkresource.Resource, error) {
	return sdkresource.Merge(
		sdkresource.Default(),
		sdkresource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceName(cfg.ServiceName),
			semconv.ServiceVersion(cfg.ServiceVersion),
			attribute.String("deployment.environment", cfg.DeploymentEnv),
			attribute.String("service.instance.id", cfg.InstanceID),
		),
	)
}
