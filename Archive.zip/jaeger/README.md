# Jaeger Configuration

This directory is reserved for Jaeger configuration files. The Jaeger service in the docker-compose.yml uses the default configuration built into the image, but you can add custom configuration files here if needed.

The Jaeger UI is accessible at: http://localhost:16686